package com.bitc.java505_team4_1.dto;

import lombok.Data;

@Data
public class FoodMonthDto {
    private int foodMNum;
    private String foodMName;
    private String foodMMonth;
}
