package com.bitc.java505_team4.dto.food;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "items")
public class FoodItems {
    private List<FoodItem> itemList;
    private int totalCount;
    private FoodItems(){};

    public FoodItems(List<FoodItem> itemList, Integer totalCount) {
        this.itemList = itemList;
        this.totalCount = totalCount;
    }

    @XmlElement(name = "item")
    public List<FoodItem> getItemList() {
        return itemList;
    }

    public void setItemList(List<FoodItem> itemList) {
        this.itemList = itemList;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }
}
