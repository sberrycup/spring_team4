package com.bitc.java505_team4.dto;

import lombok.Data;

@Data
public class FoodMonthDto {
    private int foodMNum;
    private String foodMName;
    private String foodMMonth;
}
