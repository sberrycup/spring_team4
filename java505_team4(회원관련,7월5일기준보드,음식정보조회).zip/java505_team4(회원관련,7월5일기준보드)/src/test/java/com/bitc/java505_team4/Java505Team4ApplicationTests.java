package com.bitc.java505_team4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java505Team4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
