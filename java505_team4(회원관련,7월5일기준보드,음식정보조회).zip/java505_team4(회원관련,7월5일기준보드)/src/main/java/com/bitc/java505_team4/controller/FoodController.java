package com.bitc.java505_team4.controller;

import com.bitc.java505_team4.dto.BoardDTO;
import com.bitc.java505_team4.dto.UserDto;
import com.bitc.java505_team4.dto.food.FoodItem;
import com.bitc.java505_team4.dto.food2.Food2;
import com.bitc.java505_team4.service.BoardService;
import com.bitc.java505_team4.service.FoodService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.net.URLEncoder;
import java.util.List;

@Controller
@RequestMapping("/")
public class FoodController {
    @Autowired
    private FoodService foodService;

    @GetMapping("/foodUrl")
    public ModelAndView getFoodUrl(HttpServletRequest req) throws Exception {
        ModelAndView mv = new ModelAndView("food/foodInfoPage");

        HttpSession session = req.getSession();

        UserDto user = new UserDto();
        user.setMemberEmail((String)session.getAttribute("memberEmail"));
        user.setMemberName((String)session.getAttribute("memberName"));
        user.setAdminYn((String)session.getAttribute("adminYn"));
        user.setMemberProfilePath((String)session.getAttribute("memberProfilePath"));

        mv.addObject("userInfo", user);

        return mv;
    }

    @GetMapping("/foodDiet")
    public String getFoodDiet() throws Exception {
        return "food/foodDiet";
    }

    @ResponseBody
    @PostMapping("/foodUrl")
    public Object getFoodUrl(String Page_No, String Page_Size, String fd_Nm) throws Exception {


        String url = "http://apis.data.go.kr/1390802/AgriFood/FdFoodImage/getKoreanFoodFdFoodImageList";
        String serviceKey = "?serviceKey=";
        String key = "0m0EyVE7TywORA8Zu4qti6NOPFYY6D89BGTNGTz7%2BT4uU6Cp%2B8fCsQDYypUZD5ML4Q%2BwGxBsnH2lJg0yD2Ei9g%3D%3D";
        String serviceType = "&service_Type=xml";
        String opt1 = "&Page_No=";
        String opt2 = "&Page_Size=";
        String opt3 = "&food_Name=";
        fd_Nm = URLEncoder.encode(fd_Nm, "UTF-8");

        List<FoodItem> itemList = foodService.getItemListUrl(url + serviceKey + key + serviceType + opt1 + Page_No + opt2 + Page_Size + opt3 + fd_Nm);

        return itemList;
    }

    @ResponseBody
    @PostMapping("/foodUrl2")
    public Object getFood2Url(String foodCd) throws Exception {
        String url = "http://apis.data.go.kr/1390802/AgriFood/MzenFoodNutri/getKoreanFoodIdntList";
        String serviceKey = "?serviceKey=";
        String key = "0m0EyVE7TywORA8Zu4qti6NOPFYY6D89BGTNGTz7%2BT4uU6Cp%2B8fCsQDYypUZD5ML4Q%2BwGxBsnH2lJg0yD2Ei9g%3D%3D";
        String opt1 = "&food_Code=";

        List<Food2>item2List = foodService.getItem2ListUrl(url + serviceKey + key + opt1 + foodCd);

        return item2List;
    }
}
