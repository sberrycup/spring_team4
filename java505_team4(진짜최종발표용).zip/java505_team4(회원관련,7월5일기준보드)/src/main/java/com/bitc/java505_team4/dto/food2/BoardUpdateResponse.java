package com.bitc.java505_team4.dto.food2;

import com.bitc.java505_team4.dto.BoardDTO;
import lombok.Data;

import java.util.List;

@Data
public class BoardUpdateResponse {
    private List<BoardDTO> boardList;
    private BoardDTO board;

    // 생성자, getter, setter 생략

    // 필요에 따라 다른 필드도 추가할 수 있습니다.
}