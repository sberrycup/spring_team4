package com.bitc.java505_team4.controller;

import com.bitc.java505_team4.dto.CommentDTO;
import com.bitc.java505_team4.mapper.CommentMapper;
import com.bitc.java505_team4.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class CommentController {
    @Autowired
    private CommentService commentService;

//    @RequestMapping(value = "/main/comment", method = RequestMethod.GET)
//    public ModelAndView commentList() throws Exception {
//        ModelAndView mv = new ModelAndView("main/mainBoard");
//
//        List<CommentDTO> commentList = commentService.selectCommentList();
//
//        mv.addObject("commentList", commentList);
//        return mv;
//    }

    @ResponseBody
    @PostMapping(value = "/main/insertComment")
    public String commentInsertProcess(@RequestParam("comment") String comment, @RequestParam("commentBoardNum") int commentBoardNum) throws Exception {
        CommentDTO commentDTO = new CommentDTO();
        commentDTO.setCommentBoardNum(commentBoardNum);
        commentDTO.setCommentContents(comment);
        commentService.insertComment(commentDTO);
        return "success";
    }
}
