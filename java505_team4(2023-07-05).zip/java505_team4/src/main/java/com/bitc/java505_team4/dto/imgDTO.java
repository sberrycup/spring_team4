package com.bitc.java505_team4.dto;

import lombok.Data;

@Data
public class imgDTO {
    private String imgName;
    private String imgPath;
}
