package com.bitc.java505_team4.service;

import com.bitc.java505_team4.dto.BoardDTO;
import com.bitc.java505_team4.dto.CommentDTO;
import com.bitc.java505_team4.mapper.BoardMapper;
import com.bitc.java505_team4.mapper.CommentMapper;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardServiceImpl implements BoardService {
    @Autowired
    private BoardMapper boardMapper;

    @Autowired
    private CommentMapper commentMapper;

    @Override
    public List<BoardDTO> selectBoardList() throws Exception {
        List<BoardDTO> boardList = boardMapper.selectBoardList();

        for (int i = 0; i < boardList.size(); i++) {
            List<CommentDTO> commentList = commentMapper.selectCommentList(boardList.get(i).getBoardNum());
            boardList.get(i).setCommentList(commentList);
        }

        return boardList;
    }


    @Override
    public void updateBoard(BoardDTO board) throws Exception {
        boardMapper.updateBoard(board);
    }

    @Override
    public void insertBoard(BoardDTO board) throws Exception {
        boardMapper.insertBoard(board);
    }

    @Override
    public void deleteBoard(int boardNum) throws Exception {
        boardMapper.deleteBoard(boardNum);
    }

    @Override
    public void likeUpload(int boardNum) throws Exception{
        boardMapper.likeUpdate(boardNum);
    }
}

































