package com.bitc.java505_team4.service;

import com.bitc.java505_team4.Repository.FoodBoardRepository;
import com.bitc.java505_team4.dto.BoardDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FoodBoardService {

    @Autowired
    private FoodBoardRepository foodBoardRepository;

    public List<BoardDTO> getFoodBoardList(int limit, int offset) {
        return foodBoardRepository.getFoodBoardList(limit, offset);
    }
}
