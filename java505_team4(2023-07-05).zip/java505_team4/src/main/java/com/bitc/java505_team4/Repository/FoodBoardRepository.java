package com.bitc.java505_team4.Repository;

import com.bitc.java505_team4.dto.BoardDTO;
import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodBoardRepository extends JpaRepository<BoardDTO, Long> {

    @Query(value = "SELECT board_num, board_memberName, board_contents, board_date, board_like " +
            "FROM food_board WHERE deleted_yn = 'N' " +
            "ORDER BY board_num DESC LIMIT :limit OFFSET :offset",
            nativeQuery = true)
    List<BoardDTO> getFoodBoardList(@Param("limit") int limit, @Param("offset") int offset);
}
