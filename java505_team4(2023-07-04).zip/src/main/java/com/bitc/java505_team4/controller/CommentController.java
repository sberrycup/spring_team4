package com.bitc.java505_team4.controller;

import com.bitc.java505_team4.dto.CommentDTO;
import com.bitc.java505_team4.mapper.CommentMapper;
import com.bitc.java505_team4.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class CommentController {
    @Autowired
    private CommentService commentService;

//    @RequestMapping(value = "/main/comment", method = RequestMethod.GET)
//    public ModelAndView commentList() throws Exception {
//        ModelAndView mv = new ModelAndView("main/mainBoard");
//
//        List<CommentDTO> commentList = commentService.selectCommentList();
//
//        mv.addObject("commentList", commentList);
//        return mv;
//    }

    @ResponseBody
    @RequestMapping(value = "/main/insertComment", method = RequestMethod.POST)
    public String commentInsertProcess(String comment, int boardNum) throws Exception {
        CommentDTO commentDTO = new CommentDTO();
        commentDTO.setCommentNum(boardNum);
        commentDTO.setCommentContents(comment);
        commentService.insertComment(commentDTO);
        return "success";
    }
}
